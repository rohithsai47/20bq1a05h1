import './App.css';
import MyCart from './components/MyCart';
function App() { return (
<div> <MyCart />
</div> );
}
export default App;